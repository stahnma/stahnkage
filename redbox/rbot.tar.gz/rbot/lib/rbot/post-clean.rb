File.unlink("pkgconfig.rb") if FileTest.exist?("pkgconfig.rb")
